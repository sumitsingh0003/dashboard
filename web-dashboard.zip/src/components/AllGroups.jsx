import React from 'react'
import PageHeader from "./PageHeader";


const AllGroups = () => {
  return (
    <div>
       <PageHeader name='AllGroups' />
    </div>
  )
}

export default AllGroups
